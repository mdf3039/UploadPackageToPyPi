from setuptools import setup

setup(name='CUMSUM_Change_Point_Analytics',
      version='0.1',
      description='Change Point Detection using CUMSUM Algorithm',
      packages=['CUMSUM_Change_Point_Analytics'],
	  author = 'Michael Floyd',
	  author_email = 'mdf3039b@gmail.com',
      zip_safe=False)